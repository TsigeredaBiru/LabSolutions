package cs525.project.Framework.dataaccess;



public interface ConfigProperties {

	String readProperty(String propertyName);
}
