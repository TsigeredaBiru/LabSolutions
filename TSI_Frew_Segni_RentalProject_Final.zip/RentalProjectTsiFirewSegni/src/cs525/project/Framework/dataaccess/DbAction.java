
package cs525.project.Framework.dataaccess;

import java.sql.ResultSet;

/**
 * This @{DbAction} class used for performing database actions

 */
public interface DbAction {
	/**
	 * This method Performs insert query based passed query statement
	 * @param query
	 * @return integer
	 */
	public int Create(String query);

	/**
	 * This method Performs read query based passed query statement
	 * @param query
	 * @return Object 
	 */
	public ResultSet read(String query);

	/**
	 * This method Performs delete query based passed query statement
	 * @param query
	 * @return integer
	 */
	public int delete(String query);

	/**
	 * This method Performs update query based passed query statement
	 * @param query
	 * @return integer
	 */
	public int update(String query);

}
