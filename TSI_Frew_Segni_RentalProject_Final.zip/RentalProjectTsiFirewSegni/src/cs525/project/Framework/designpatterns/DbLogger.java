package cs525.project.Framework.designpatterns;

/*
 
/**
 * provides a class to implement the logging in database
 
 *
 */
public class DbLogger extends LoggerDecorator {

	public DbLogger(Logger logger) {
		super(logger);
	}

}
