package cs525.project.Framework.designpatterns;


 

/**
 * provides a class for sending text message

 *
 */
public class TextMessageSender implements MessageSender {

	@Override
	public void sendMessage(String body, Person person) {
		// TODO Auto-generated method stub

	}

}
