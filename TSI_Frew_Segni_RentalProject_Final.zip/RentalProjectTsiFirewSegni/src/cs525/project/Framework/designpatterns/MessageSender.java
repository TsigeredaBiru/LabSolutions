package cs525.project.Framework.designpatterns;



/**
 * MessageSender Interface is the Implementor of Bridge Pattern hierarchy
 * ('Bridge/Implementor' interface) Clients can implement this interface for
 * sending text/Email.... messages
 
 */

public interface MessageSender {
	/**
	 * Method for sending message the implementation will be made by application
	 * user
	 * 
	 * @param body
	 *            this is an email body
	 * @param Person
	 *            to whom the email is sent
	 */
	public void sendMessage(String body, Person person);
}
