package cs525.project.Framework.designpatterns;



/**
 * Refined Abstraction of Message Class

 */
public class EmailMessage extends Message {
	/**
	 * EmailMessage constructor with @{MessageSender} as a parameter
	 * 
	 * @param messageSender
	 */
	public EmailMessage(MessageSender messageSender) {
		super(messageSender);
	}

	@Override
	public void send() {
		messageSender.sendMessage(body,person);

	}

}
