package cs525.project.Framework.designpatterns;


 

/**
 * provides a concrete implementation for SMS notification strategy

 */
public class SMSNotificationStrategy implements NotificationStrategy {

	private Message message;

	public SMSNotificationStrategy() {
		this.message = new TextMessage(new TextMessageSender());
	}

	@Override
	public void sendNotification(String message, Person person) {

		this.message.setBody(message);
		this.message.setPerson(person);
		this.message.send();
	}

}
