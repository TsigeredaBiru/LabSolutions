package cs525.project.Framework.designpatterns;



/**
 * provides an interface for factory method

 */
public interface PersonFactory {
	/**
	 * creates concrete implementation of person
	 * 
	 * @param type
	 *            the type of Person
	 * @return PersonFactory an instance of PersonFactory
	 * 
	 */
	public Person createPerson(String type);
}
