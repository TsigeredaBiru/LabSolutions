package cs525.project.Framework.designpatterns;



/**
 * provides an interface for getting logger instance
 
 *
 */
public interface Logger {

	/**
	 * logs warning message
	 * 
	 * @param message
	 * @return
	 */
	String warn(String message);

	/**
	 * logs debug message
	 * 
	 * @param message
	 * @return
	 */
	String debug(String message);

	/**
	 * logs info message
	 * 
	 * @param message
	 * @return
	 */
	String info(String message);

	/**
	 * logs error message
	 * 
	 * @param message
	 * @return
	 */
	String error(String message);
}
