package cs525.project.Framework.designpatterns;

import cs525.project.Framework.model.CheckoutRecordEntry;
import cs525.project.Framework.model.CheckoutRecordFacade;
import cs525.project.Framework.model.CheckoutRecordProtectionProxy;

/**
 * provides concrete command for checkout record save operation

 */
public class CheckoutCommand implements Command {

	private CheckoutRecordFacade facade;
	private CheckoutRecordEntry checkoutRecordEntry;

	public CheckoutCommand(CheckoutRecordEntry checkoutRecordEntry) {
		this.facade = new CheckoutRecordProtectionProxy();
		this.checkoutRecordEntry = checkoutRecordEntry;
	}

	@Override
	public boolean execute() {

		int affectedRows = facade.saveCheckoutRecord(checkoutRecordEntry);
		return affectedRows == 1 ? true : false;
	}

	@Override
	public boolean undo() {

		int affectedRows = facade.removeCheckoutRecord(checkoutRecordEntry);
		return affectedRows == 1 ? true : false;
	}

}
