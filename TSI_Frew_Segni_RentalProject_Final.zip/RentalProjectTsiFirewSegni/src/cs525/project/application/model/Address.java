package cs525.project.application.model;




public class Address extends cs525.project.Framework.model.Address {

	public Address(String streetAddress, String city, int zipCode, String state) {
		super(streetAddress, city, zipCode, state);
	}	
	

}
