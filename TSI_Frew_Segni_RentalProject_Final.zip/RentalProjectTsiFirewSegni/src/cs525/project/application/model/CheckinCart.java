package cs525.project.application.model;


public class CheckinCart {

}
