

package cs525.project.Framework.dataaccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



/**
 * singleton class for managing the connection pool

 */
public class SimpleConnectionPool {
	private static SimpleConnectionPool instance;

	private SimpleConnectionPool() {
	}

	/**
	 * This method returns single instance of @{SimpleConnectionPool} using if
	 * it is not already created.
	 * 
	 * @return instance
	 */
	public static SimpleConnectionPool getInstance() {
		if (instance == null) {
			instance = new SimpleConnectionPool();
		}
		return instance;
	}

	/**
	 * This method return connection object
	 * 
	 * @return
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		String url = "jdbc:mysql://localhost:3306/";
		String dbName = "carrentalsystem";
		String driver = "com.mysql.jdbc.Driver";
		String userName = "root";
		String password = "root";
		
		/*dburl =jdbc:mysql:///carrentalsystem
			max_connections=4
			driver=org.gjt.mm.mysql.Driver
			dbuser=root
			dbpassword=root*/
		//DbConfig config = new DbConfig();
		Connection con = null;
		Logger consoleLogger = new ConsoleLogger(new LoggerImpl());
		try {
			Class.forName(driver).newInstance();
			//Class.forName(config.getDriver());

			consoleLogger.debug("URL:" + dbName + " UserName: " + userName + " Password: "
					+ password);
			con = DriverManager.getConnection(url+dbName,userName,password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

}
