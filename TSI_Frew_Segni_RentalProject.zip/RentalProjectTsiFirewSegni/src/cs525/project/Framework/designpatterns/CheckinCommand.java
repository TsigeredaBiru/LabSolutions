package cs525.project.Framework.designpatterns;

import cs525.project.Framework.model.CheckoutRecordEntry;
import cs525.project.Framework.model.CheckoutRecordFacade;
import cs525.project.Framework.model.CheckoutRecordProtectionProxy;


/**
 * provides concrete command for check in record save operation

 */
public class CheckinCommand implements Command {

	private CheckoutRecordFacade facade;
	private CheckoutRecordEntry checkoutRecordEntry;

	public CheckinCommand(CheckoutRecordEntry checkoutRecordEntry) {
		this.facade = new CheckoutRecordProtectionProxy();
		this.checkoutRecordEntry = checkoutRecordEntry;
	}

	@Override
	public boolean execute() {
		int affectedRows = facade.checkInRecord(checkoutRecordEntry);
		return affectedRows == 1 ? true : false;
	}

	@Override
	public boolean undo() {
		int affectedRows = facade.undoCheckIn(checkoutRecordEntry);
		return affectedRows == 1 ? true : false;
	}

}
