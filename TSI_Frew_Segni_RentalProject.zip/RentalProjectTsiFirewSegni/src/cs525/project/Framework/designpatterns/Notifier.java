package cs525.project.Framework.designpatterns;



/**
 * provides context class for the notification strategy

 *
 */
public class Notifier {

	private NotificationStrategy notificationStrategy;

	/**
	 * constructor
	 * 
	 * @param notificationStrategy
	 *            strategy to be selected for the notification to user
	 */
	public Notifier(NotificationStrategy notificationStrategy) {
		this.notificationStrategy = notificationStrategy;
	}

	/**
	 * notifies a customer with notification message about the checkout details
	 * and due date for checking back in
	 * 
	 * @param person
	 *            customer for which the notification needs to be sent
	 */
	public void notifyPerson(String message, Person person) {
		notificationStrategy.sendNotification(message, person);
	}
}
