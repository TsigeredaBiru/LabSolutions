package cs525.project.Framework.designpatterns;



/**
 * SortedListIterator/Iterator interface Allows clients to access and traverse
 
 * 
 */
public interface SortedListIterator {
	/**
	 * traverse the element and returns true if the given element has next
	 * element
	 * 
	 * @return
	 */
	public boolean hasNext();

	/**
	 * This method check if the element has next element and returns it if it
	 * has nexxt element
	 * 
	 * @return Next Object
	 */
	public Object next();

	/**
	 * 
	 * @return current object
	 */
	public Object currentItem();
}
