package cs525.project.Framework.designpatterns;

import cs525.project.Framework.model.Customer;

/**
 * factory method implementation to create persons

 */
public class PersonFactoryImpl implements PersonFactory {
	private static PersonFactory factory = new PersonFactoryImpl();

	/**
	 * private constructor to avoid instantiation
	 */
	public PersonFactoryImpl() {
	}

	public static PersonFactory getFactory() {
		return factory;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * cs525.project.fujframework.middleware.PersonFactory#createPerson(java.
	 * lang.String)
	 */
	@Override
	public Person createPerson(String type) {
		Person person = null;
		if (type.equals("customer")) {
			person = (Person) new Customer();
		} else if (type.equals("sysuser")) {
			person = new SysUser();
		}
		return person;
	}

}
