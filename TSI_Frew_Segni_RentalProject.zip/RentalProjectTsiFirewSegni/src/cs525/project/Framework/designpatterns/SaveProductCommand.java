package cs525.project.Framework.designpatterns;

import cs525.project.Framework.model.Product;
import cs525.project.Framework.model.ProductFacade;
import cs525.project.Framework.model.ProductFacadeImpl;

/**
 * concrete command for product save operation
 
 *
 */
public class SaveProductCommand implements Command {

	private Product product;
	private ProductFacade facade;

	public SaveProductCommand(Product product) {
		this.product = product;
		facade = new ProductFacadeImpl();
	}

	@Override
	public boolean execute() {
		int affectedRows = facade.saveProduct(product);
		return affectedRows == 1 ? true : false;
	}

	@Override
	public boolean undo() {
		int affectedRows = facade.removeProduct(product);
		return affectedRows == 1 ? true : false;
	}

}
