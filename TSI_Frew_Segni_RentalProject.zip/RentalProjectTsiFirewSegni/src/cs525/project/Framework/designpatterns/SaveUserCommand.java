package cs525.project.Framework.designpatterns;

import cs525.project.Framework.model.SysUser;
import cs525.project.Framework.model.SysUserFacade;
import cs525.project.Framework.model.SysUserFacadeImpl;

/**
 * concrete command for user save operation
 
 *
 */
public class SaveUserCommand implements Command {

	private SysUserFacade facade;
	private SysUser user;

	public SaveUserCommand(SysUser user) {
		this.user = user;
		this.facade = new SysUserFacadeImpl();
	}

	@Override
	public boolean execute() {
		int affectedRows = facade.saveSysUser(user);
		return affectedRows == 1 ? true : false;
	}

	@Override
	public boolean undo() {
		int affectedRows = facade.removeSysUser(user);
		return affectedRows == 1 ? true : false;
	}

}
