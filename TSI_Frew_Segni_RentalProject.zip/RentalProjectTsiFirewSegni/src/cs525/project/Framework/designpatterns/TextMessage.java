package cs525.project.Framework.designpatterns;


 

/**
 * Refined Abstraction of Message Class
 
 *
 */
public class TextMessage extends Message {
	/**
	 * @{TextMessage} constructor which is implementation of
	 *                abstraction @{Message}
	 * @param messageSender
	 */
	public TextMessage(MessageSender messageSender) {
		super(messageSender);
	}

	@Override
	public void send() {
		messageSender.sendMessage(body, person);

	}

}
