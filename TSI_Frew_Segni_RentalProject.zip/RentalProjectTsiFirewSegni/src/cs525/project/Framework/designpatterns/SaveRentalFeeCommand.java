package cs525.project.Framework.designpatterns;



/**
 * provides a concrete class for saving rental fee
 * 

 *
 */

// it is not currently in use based on our architecture in this version
public class SaveRentalFeeCommand implements Command {

	@Override
	public boolean execute() {
		return false;
	}

	@Override
	public boolean undo() {
		return false;
	}

}
