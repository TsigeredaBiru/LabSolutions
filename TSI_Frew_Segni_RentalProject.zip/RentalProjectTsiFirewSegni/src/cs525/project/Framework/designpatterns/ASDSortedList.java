package cs525.project.Framework.designpatterns;



/**
 * This is Aggregate interface of ASDSortedList which uses instance of
 * SortedListIterator for creating Iterator

 */
public interface ASDSortedList {
	/**
	 * 
	 * @param @{Predicate<T>}
	 *            which is implemented by user application
	 * @return @{SortedListIterator} type
	 */
	public SortedListIterator createIterator(Predicate<String> functor);
}
