package cs525.project.Framework.designpatterns;



/**
 * provides an interface for sending notification after the check out process to
 * a customer
 
 *
 */
public interface NotificationStrategy {

	/**
	 * sends notification to the customer - which can be an Email or SMS message
	 * 
	 * @param message
	 *            the message that needs to be sent
	 * @param person
	 *            customer for which the notification has to be sent
	 * 
	 */
	void sendNotification(String message, Person person);
}
