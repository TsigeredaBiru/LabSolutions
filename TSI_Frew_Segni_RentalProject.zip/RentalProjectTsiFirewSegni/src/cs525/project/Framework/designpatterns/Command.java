package cs525.project.Framework.designpatterns;



public interface Command {

	/**
	 * executes the command invoking an appropriate operation from the receiver
	 * 
	 * @return boolean
	 */
	boolean execute();

	/**
	 * roll-backs the recently executed operation
	 * 
	 * @return boolean
	 */
	boolean undo();
}
