package cs525.project.Framework.model;



import java.sql.ResultSet;

import cs525.project.Framework.dataaccess.DbAction;
import cs525.project.Framework.dataaccess.DbActionImpl;
import cs525.project.Framework.dataaccess.DbHelper;




public class ProductFacadeImpl implements ProductFacade {
	private DbAction dbaction;
	StringBuilder queryBuilder;

	public ProductFacadeImpl() {
		this.dbaction = new DbActionImpl();
	}

	
	@Override
	public int saveProduct(Product product) {
		if (product.getProductId() > 0)
			return this.dbaction.update(DbHelper.getUpdateQuery(product));
		return this.dbaction.Create(DbHelper.getInsertQuery(product));
	}

	
	@Override
	public int removeProduct(Product product) {
		queryBuilder = new StringBuilder();
		queryBuilder.append("DELETE FROM product WHERE productId=" + product.getProductId());
		return this.dbaction.delete(queryBuilder.toString());
	}

	
	@Override
	public ResultSet getProductById(int productId, Class<?> tableName) {
		queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT * FROM " + tableName.getSimpleName() + " where productId = " + productId);
		return this.dbaction.read(queryBuilder.toString());
	}

	@Override
	public ResultSet getAllProduct(Class<?> tableName) {
		queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT * FROM " + tableName.getSimpleName());
		return this.dbaction.read(queryBuilder.toString());
	}

}
