package cs525.project.Framework.model;



import java.sql.ResultSet;


public interface ProductFacade {
	
	public int saveProduct(Product product);

	
	public int removeProduct(Product product);

	
	public ResultSet getProductById(int productId, Class<?> tableName);
	
	
	public ResultSet getAllProduct(Class<?> tableName);
}
