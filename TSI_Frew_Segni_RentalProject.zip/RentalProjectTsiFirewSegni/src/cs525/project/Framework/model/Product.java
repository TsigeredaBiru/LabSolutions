package cs525.project.Framework.model;


public interface Product {
	
	public void setProductId(int productId);

	
	public int getProductId();

	
	public void setProductName(String productName);

	
	public String getProductName();

	
	public void setRentalFeePerDay(double rentalFee);

	
	public double getRentalFeePerDay();

	
	public void setOverDueFinePerDay(double rentalFee);

	
	public double getOverDueFinePerDay();

}
