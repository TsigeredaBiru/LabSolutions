package cs525.project.Framework.model;



/**
 * factory method implementation to create persons
 
 */
public class PersonFactoryImpl implements PersonFactory {
	private static PersonFactory factory = new PersonFactoryImpl();

	/**
	 * private constructor to avoid instantiation
	 */
	public PersonFactoryImpl() {
	}

	public static PersonFactory getFactory() {
		return factory;
	}

	@Override
	public Person createPerson(String type) {
		Person person = null;
		if (type.equals("customer")) {
			person = new Customer();
		} else if (type.equals("sysuser")) {
			person = new SysUser();
		}
		return person;
	}

}
