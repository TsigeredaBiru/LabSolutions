package cs525.project.Framework.model;



import java.sql.ResultSet;


public interface CustomerFacade {

	public int saveCustomer(Customer customer);

	
	public int removeCustomer(Customer customer);

	
	public ResultSet getCustomerById(int customerId);

	
	public ResultSet getAllCustomers(Class<?> tableName);
	
	
	public ResultSet getAddressByCustomerId(int customerId,Class<?> tableName);
}
