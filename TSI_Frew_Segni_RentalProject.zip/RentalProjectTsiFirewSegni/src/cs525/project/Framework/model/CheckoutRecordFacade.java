package cs525.project.Framework.model;

import java.sql.ResultSet;


public interface CheckoutRecordFacade {
	
	public int saveCheckoutRecord(CheckoutRecordEntry checkoutRecordEntry);

	
	public int removeCheckoutRecord(CheckoutRecordEntry checkoutRecordEntry);

	
	public int checkInRecord(CheckoutRecordEntry checkoutRecordEntry);

	
	public int undoCheckIn(CheckoutRecordEntry checkoutRecordEntry);

	
	public ResultSet getAllCheckoutRecordsByCustomer(int customerId, Class<?> tableName, Class<?> joinTableName);

	
	public ResultSet getAllCheckoutRecordsByCustomerAndUser(int customerId, int userId, Class<?> tableName);
	
	
	public ResultSet getAllCheckoutRecords(Class<?> tableName);
}
