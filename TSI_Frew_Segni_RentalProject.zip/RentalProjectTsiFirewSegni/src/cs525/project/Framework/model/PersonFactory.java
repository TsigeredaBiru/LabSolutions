package cs525.project.Framework.model;




public interface PersonFactory {
	/**
	 
	 * @return PersonFactory an instance of PersonFactory
	 * 
	 */
	public Person createPerson(String type);
}
