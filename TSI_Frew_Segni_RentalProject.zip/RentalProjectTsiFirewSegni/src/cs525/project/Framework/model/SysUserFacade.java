package cs525.project.Framework.model;



import java.sql.ResultSet;

public interface SysUserFacade {

	
	public int saveSysUser(SysUser sysUser);

	
	public int removeSysUser(SysUser sysUser);

	
	public ResultSet getAllUsers(Class<?> tableName);

	public ResultSet getUserByUserNameAndPassword(String userName,String password,Class<?> userTable);
}
