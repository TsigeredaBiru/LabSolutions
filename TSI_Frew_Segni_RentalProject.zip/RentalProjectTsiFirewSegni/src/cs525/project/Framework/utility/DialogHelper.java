package cs525.project.Framework.utility;



import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

/**
 * @author OWNER
 *
 */
public class DialogHelper {

	public static void toast(String msg, AlertType alertType) {
		Alert alert = new Alert(alertType);
		alert.setTitle(alertType.name());
		alert.setHeaderText(msg);
		alert.showAndWait();
	}

}
