package cs525.project.application.presentation;


import cs525.project.application.controller.LoginController;
import javafx.application.Application;
import javafx.stage.Stage;
import cs525.project.application.*;

public class MainForm extends Application {
	@Override
	public void start(Stage primaryStage) throws Exception {
		LoginController manageCustomer = new LoginController();
		manageCustomer.start(primaryStage);

	}

	public static void main(String[] args) {
		launch(args);
	}
}
