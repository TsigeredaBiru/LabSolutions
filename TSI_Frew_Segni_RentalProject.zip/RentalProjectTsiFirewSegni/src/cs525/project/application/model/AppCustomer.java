package cs525.project.application.model;

import cs525.project.Framework.model.Customer;

public class AppCustomer extends Customer {	
	private String phone;
	
	public void setPhone(String phoneNumber) {
		this.phone = phoneNumber;
	}

	public String getPhone() {
		return this.phone;
	}

}
