package cs525.project.application.model;

import cs525.project.Framework.model.CheckoutRecordEntry;

public class CheckinData extends CheckoutRecordEntry {
	private String name;
	private String model;
	private double rentalFeePerDay;
	private double rentalFinePerDay;
	private double rentalFee;

	public String getName() {
		return name;
	}

	
	public void setName(String name) {
		this.name = name;
	}

	
	public String getModel() {
		return model;
	}

	
	public void setModel(String model) {
		this.model = model;
	}

	
	public double getRentalFeePerDay() {
		return rentalFeePerDay;
	}

	
	public void setRentalFeePerDay(double rentalFeePerDay) {
		this.rentalFeePerDay = rentalFeePerDay;
	}

	/**
	 * @return the rentalFinePerDay
	 */
	public double getRentalFinePerDay() {
		return rentalFinePerDay;
	}


	public void setRentalFinePerDay(double rentalFinePerDay) {
		this.rentalFinePerDay = rentalFinePerDay;
	}

	
	public double getRentalFee() {
		return rentalFee;
	}

	
	public void setRentalFee(double rentalFee) {
		this.rentalFee = rentalFee;
	}

	
	@Override
	public String toString() {
		return "CheckinData [name=" + name + ", model=" + model + ", rentalFeePerDay=" + rentalFeePerDay
				+ ", rentalFinePerDay=" + rentalFinePerDay + ", rentalFee=" + rentalFee + "]";
	}

}
