package cs525.project.application.model;

import cs525.project.Framework.model.SysUser;
import cs525.project.Framework.model.*;

public class ApplicationUser extends SysUser {
	String userName;
	String password;
	String phone;
	boolean isAdmin;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	
	public String getPassword() {
		return password;
	}

	
	public void setPassword(String password) {
		this.password = password;
	}

	
	public void setIsAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	
	public boolean isAdmin() {
		return isAdmin;
	}
	
	

	public String getPhone() {
		return phone;
	}

	
	public void setPhone(String phone) {
		this.phone = phone;
	}

	/*@Override
	public void setAddress(Address address) {
		super.setAddress(null);
	}*/

}
