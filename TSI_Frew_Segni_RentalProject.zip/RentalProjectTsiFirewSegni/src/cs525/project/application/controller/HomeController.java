package cs525.project.application.controller;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.net.URL;
import java.util.ResourceBundle;

import cs525.project.Framework.dataaccess.BusinessConstants;
import cs525.project.Framework.dataaccess.Logger;
import cs525.project.Framework.dataaccess.SessionCache;
import cs525.project.Framework.model.CheckoutRecordEntry;
import cs525.project.Framework.model.CheckoutRecordFacade;
import cs525.project.Framework.model.CheckoutRecordProtectionProxy;
import cs525.project.Framework.model.LoginUtil;
import cs525.project.application.model.KeyValuePair;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuBar;
import javafx.scene.control.Menu;
import javafx.scene.image.Image;
import javafx.stage.Stage;


public class HomeController extends Application implements Initializable {

	private Logger logger;
	@FXML
	private MenuBar menubar;

	private CheckoutRecordFacade facade;

	@FXML
	private Menu carMenu;

	@FXML
	private Menu userMenu;

	@FXML
	private Menu customerMenu;

	@FXML
	private Menu transactionMenu;



	

	@Override
	public void start(Stage primaryStage) throws Exception {

		Parent root = FXMLLoader
				.load(getClass().getClassLoader().getResource("cs525/project/application/presentation/MainForm.fxml"));
		Scene scene = new Scene(root,200,500);
		// scene.getStylesheets().add("cs525/rentalcarsystem/presentation/background.css");
		primaryStage.getIcons().add(new Image("file:resources/images/icon.png"));
		primaryStage.setResizable(true);
		primaryStage.setTitle("Home - Car Rental System [V1.0.0]");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

	public HomeController() {
		//this.logger = new ConsoleLogger(new LoggerImpl());
		this.facade = new CheckoutRecordProtectionProxy();
	}

	@FXML
	protected void listUsersMenuAction(ActionEvent event) throws Exception {

		checkForUserAccessPrivilege();
		if (LoginUtil.isStaff())
			return;

		Stage stage = new Stage();
		ApplicationUserController controller = new ApplicationUserController();
		controller.start(stage);
	}

	@FXML
	protected void addUserMenuAction(ActionEvent event) throws Exception {

		checkForUserAccessPrivilege();
		if (LoginUtil.isStaff())
			return;

		Stage stage = new Stage();
		ApplicationUserController controller = new ApplicationUserController();
		controller.start(stage);
	}

	@FXML
	protected void listCustomersMenuAction(ActionEvent event) throws Exception {

		checkForUserAccessPrivilege();
		if (LoginUtil.isStaff())
			return;

		Stage stage = new Stage();
		ManageCustomerController controller = new ManageCustomerController();
		controller.start(stage);
	}

	@FXML
	protected void addCustomerMenuAction(ActionEvent event) throws Exception {
		checkForUserAccessPrivilege();
		if (LoginUtil.isStaff())
			return;

		Stage stage = new Stage();
		AddCustomerController controller = new AddCustomerController();
		controller.start(stage);
	}

	@FXML
	protected void listCarsMenuAction(ActionEvent event) throws Exception {
		checkForUserAccessPrivilege();
		if (LoginUtil.isStaff())
			return;
		Stage stage = new Stage();
		CheckoutController controller = new CheckoutController("Car List - Car Rental System");
		controller.start(stage);
	}

	@FXML
	protected void addCarMenuAction(ActionEvent event) throws Exception {
		checkForUserAccessPrivilege();
		if (LoginUtil.isStaff())
			return;

		Stage stage = new Stage();
		CarController controller = new CarController();
		controller.start(stage);
	}

	@FXML
	protected void checkoutMenuAction(ActionEvent event) throws Exception {
		Stage stage = new Stage();
		CheckoutController controller = new CheckoutController("Checkout Car(s) - Car Rental System");
		controller.start(stage);
	}

	@FXML
	protected void checkinMenuAction(ActionEvent event) throws Exception {
		Stage stage = new Stage();
		CheckinFormController controller = new CheckinFormController();
		controller.start(stage);
	}

	@FXML
	protected void logoutMenuAction(ActionEvent event) throws Exception {

		SessionCache session = SessionCache.getInstance();
		try {
			session.remove(BusinessConstants.ADMIN);
			session.remove(BusinessConstants.STAFF);
			session.remove(BusinessConstants.LOGGED_IN);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		}

		menubar.getScene().getWindow().hide();

		Stage stage = new Stage();
		LoginController controller = new LoginController();
		controller.start(stage);

	}


	@FXML
	protected void exitMenuAction(ActionEvent event) throws Exception {

		System.exit(0);
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		if (LoginUtil.isStaff()) {
			userMenu.setDisable(true);
			customerMenu.setDisable(true);
			carMenu.setDisable(true);
		} else if (LoginUtil.isAdmin()) {
			userMenu.setDisable(false);
			customerMenu.setDisable(false);
			carMenu.setDisable(false);
		}

	
	}


	
public List<KeyValuePair<LocalDate, Integer>> getCheckoutDates() {

		List<KeyValuePair<LocalDate, Integer>> dates = new ArrayList<>();

		ResultSet rs = facade.getAllCheckoutRecords(CheckoutRecordEntry.class);
		try {
			while (rs.next()) {

				dates.add(new KeyValuePair<>(rs.getDate("checkoutDate").toLocalDate(), rs.getInt("quantity")));

			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return dates;

	}

	private void checkForUserAccessPrivilege() {

		if (LoginUtil.isStaff()) {
			userMenu.setDisable(true);
			customerMenu.setDisable(true);
			carMenu.setDisable(true);
		} else if (LoginUtil.isAdmin()) {
			userMenu.setDisable(false);
			customerMenu.setDisable(false);
			carMenu.setDisable(false);
		}

	}
}
